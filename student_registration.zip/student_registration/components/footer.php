<!-- footer section starts  -->

<footer class="footer">

   <section class="flex">

      <div class="box">
         <a href="tel:650665871"><i class="fas fa-phone"></i><span>650665871</span></a>
         <a href="tel:675071913"><i class="fas fa-phone"></i><span>675071913</span></a>
         <a href="mailto:joeltabe3@gmail.com"><i class="fas fa-envelope"></i><span>landmark@gmail.com</span></a>
         <a href="#"><i class="fas fa-map-marker-alt"></i><span>chiefstreet molyko, Buea</span></a>
      </div>

      <div class="box">
         <a href="home.php"><span>home</span></a>
         <a href="about.php"><span>about</span></a>
         <a href="contact.php"><span>contact</span></a>
      </div>

      <div class="box">
         <a href="#"><span>facebook</span><i class="fab fa-facebook-f"></i></a>
         <a href="#"><span>twitter</span><i class="fab fa-twitter"></i></a>
         <a href="#"><span>linkedin</span><i class="fab fa-linkedin"></i></a>
         <a href="#"><span>instagram</span><i class="fab fa-instagram"></i></a>

      </div>

   </section>

   <div class="credit">&copy; copyright @ <?= date('Y'); ?> by <span>landmark technologies</span> | all rights reserved!</div>

</footer>

<!-- footer section ends -->
